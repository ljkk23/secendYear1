MOUNT C: C:\hbyy
C: