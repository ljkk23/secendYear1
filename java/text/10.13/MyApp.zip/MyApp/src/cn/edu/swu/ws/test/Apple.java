package cn.edu.swu.ws.test;

public class Apple extends Fruit {
    @Override
    public String getName() {
        return "apple";
    }

    @Override
    public int getTotal() {
        return 10;
    }
}
