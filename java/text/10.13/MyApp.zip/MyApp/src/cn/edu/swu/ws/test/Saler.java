package cn.edu.swu.ws.test;

public class Saler<T> {

    public void sale(T product) {
        System.out.println("sale " + product);
    }

}
