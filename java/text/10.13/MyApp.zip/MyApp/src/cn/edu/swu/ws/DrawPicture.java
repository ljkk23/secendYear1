package cn.edu.swu.ws;

public interface DrawPicture {
    public void draw(String theme);
}
