package cn.edu.swu.ws.test;

public class Weapon {
}
