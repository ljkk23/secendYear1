package cn.edu.swu.ws.test;

public abstract class Fruit {

    public abstract String getName();
    public abstract int getTotal();
}
