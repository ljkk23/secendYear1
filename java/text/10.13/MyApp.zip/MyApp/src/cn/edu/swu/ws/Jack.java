package cn.edu.swu.ws;

public interface Jack {
    public void draw();
    public void fly();
    public void swim();
}
