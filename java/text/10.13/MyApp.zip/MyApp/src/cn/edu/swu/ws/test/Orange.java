package cn.edu.swu.ws.test;

public class Orange extends Fruit {
    @Override
    public String getName() {
        return "orange";
    }

    @Override
    public int getTotal() {
        return 20;
    }
}
